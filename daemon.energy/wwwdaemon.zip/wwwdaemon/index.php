<!DOCTYPE html>
<html lang="en">
<head>

<title>tuyaDAEMON energia</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/pages/dashboard.css" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <?php

	  // this setup the notes widget...
      $d=dirname(__FILE__);
      include("$d/daemon-use.php");      //  the langage file
      include("$d/interface.php");       //  php stuff
 // =============== one time statup: setup data and code js, internalization.
 // ------------ to be used in js:
      $array_monthNames = makeJavaArray( 'monthNames', $monthNames);
      $array_monthNamesShort = makeJavaArray( 'monthNamesShort', $monthNamesShort);
      $array_dayNames = makeJavaArray( 'dayNames', $dayNames);
      $array_dayNamesShort = makeJavaArray( 'dayNamesShort', $dayNamesShort);
// ------------ data for grafh
 // updates db to 'now'

  $query1  = "CALL  `storico`.`do_refreshPower`();";
  $db = new mysqli($servername, $username, $password, $datastorage );
  if ($db->connect_errno) {
      die('Errore nella connessione al database.'. $db->connect_error);
      }
  $result = $db->query($query1);
  $db->close();

    $query2  = "SELECT * FROM (SELECT * from `storico`.`power1h` ORDER BY `timestamp` DESC LIMIT 25) AS tmp ORDER BY `timestamp` asc ;";
  //  $query2  = "SELECT * from `storico`.`power1h` ORDER BY `timestamp` DESC LIMIT 25 ;";
    $db = new mysqli($servername, $username, $password, $datastorage );
    if ($db->connect_errno) {
        die('Errore nella connessione al database.'. $db->connect_error);
        }
    $result = $db->query($query2);

// ===  transforms DATA to a js array of arrays (DBdata).
   $data = '' ;
   $colonne =  $db->field_count;
   echo "<script> \n var DBdata =[ \n";

    while($row = $result->fetch_array()) {
		         echo '[ ';
 		      	 for($c = 0; $c < $colonne; $c++) {
                    if ($c == 0){

               $h = substr($row[0],11,2);
               if (substr( $h, 0, 1 ) === "0")
                   $h = substr($h,1);
               if ($h == 0) {
                 echo  '"'. substr($row[0],5,5).'"';
               } else
                 echo  '"'.$h.'"';
             } else  {
                 echo ','.($row[$c]?$row[$c]:0);  // to replace NULL with 0
                        }
            }
                  echo " ], \n ";
                  }

                 echo " []]; </script>";

  //   $db->free_result($result);
  while($db->next_result()){
     if($l_result = $db->store_result()){
             $l_result->free();
     }
   }

  $db->close();

  // make $MonthBody
    $query3  = "SELECT * FROM `storico`.`month power` ORDER BY `timestamp`;";
  //  $query2  = "SELECT * from `storico`.`power1h` ORDER BY `timestamp` DESC LIMIT 25 ;";
    $db = new mysqli($servername, $username, $password, "storico");
    if ($db->connect_errno) {
        die('Errore nella connessione al database.'. $db->connect_error);
        }
    $result = $db->query($query3);
    $MonthBody ='<tbody>';
    while($row = $result->fetch_array()) {
      $MonthBody .= '<tr>';
        for($i=1; $i<6; $i++) {
          if($i ==1)
            $MonthBody .= '<th scope="row">'.$row[$i].'</th>';
          else
            $MonthBody .= '<td>'.$row[$i].'</td>';
           }
      $MonthBody .= '</tr>';
    }
    $MonthBody .='</tbody>';

    $db->close();

    // -----
  // ================================ notes widget update
  // the HTML code for last 5 notes is pre-built in php var $notes, echoed at the rigth place

  // -----
// ================================ notes widget update
// the HTML code for last 5 notes is pre-built in php var $notes, echoed at the rigth place

$noteTemplate ='
<li>
    <div class="news-item-date">
      <span class="news-item-day"><!-- DAY --></span> <span class="news-item-month"><!-- MONTH --></span>
    </div>
    <div class="news-item-detail">
      <h4 style="color: #66CC33" class="news-item-title" target="_blank"><!-- TITLE --></h4>
      <p class="news-item-preview"><!-- BODY --></p>
    </div>
</li>';

/*
Array ( [0] => 1 [id] => 1
[1] => 2014-08-12 09:00:00 [date] => 2014-08-12 09:00:00
[2] => titolo [title] => titolo
[3] => text [body] => text )
*/

   $notes = '';
   $query  = "SELECT * FROM notes ORDER BY ndate DESC LIMIT 5";
    // connection php-db
 //  $db = new SQLite3('/mnt/sda1/datalogger.sqlite');
   $db = new mysqli($servername, $username, $password, $appdbase );
   if ($db->connect_error) die('INTERNAL ERROR: Error in access db.');
    // query
   $result = $db->query($query);
   if ($result===false) die('INTERNAL ERROR: Error in query.' );
// ===  build $note
    $colonne =  $db->field_count;
    while($row = $result->fetch_array()) {
 //   print_r($row);
		$ndata = $noteTemplate;
		$day = "";
        // 2014-08-12 09:00:00
        // 01234567890
		 if (substr( $row[1],8,1) == "0"){
			  $day = substr( $row[1],9,1);
			} else {
			  $day = substr( $row[1],8,2);
			}
		$ndata = str_replace("<!-- DAY -->",$day,$ndata);
		$nm = substr( $row[1],5,2);
		$month = $monthNamesShort[$nm - 1];
		$ndata = str_replace("<!-- MONTH -->",$month,$ndata);
		$ndata = str_replace("<!-- TITLE -->",urldecode($row[2]),$ndata);
		$max_length = 60;
		$showtext =urldecode($row[3]);
		$l = mb_strlen($showtext);
		if ($l > $max_length){
			$showtext =  mb_substr($showtext, 0, $max_length, 'UTF-8')." ...(<a href='note.php'>more</a>)";
			}
		$ndata = str_replace("<!-- BODY -->", $showtext, $ndata);
		$notes .= $ndata;
		} // while
    $db->close();

    // get start values offset for kWh
    $firstday = date("Y-m-01");
    $query3  = "SELECT * from `storico`.`power1h` WHERE `timestamp` >= '$firstday' ORDER BY `timestamp` ASC LIMIT 1 ;";
    //  $query2  = "SELECT * from `storico`.`power1h` ORDER BY `timestamp` DESC LIMIT 25 ;";
    $db = new mysqli($servername, $username, $password, $datastorage );
    if ($db->connect_errno) {
        die('Errore nella connessione al database.'. $db->connect_error);
        }
    $result = $db->query($query3);

    $row = $result->fetch_array();
//  for jscript code...
    $offsAC = $row?$row[4]:0;
    $offsPV  =$row?$row[8]:0;
    $db->close();

// ------- Snotes pre-build ends....
?>

</head>
<body  onload="myentryFunction();" onbeforeunload="myexitFunction();" >

<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"><span
                    class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span> </a><a class="brand" href="index.html">TuyaDaemon <?php echo $Translation['Dashboard']; ?>  </a>
      <div class="nav-collapse">
        <ul class="nav pull-right">

		  <li class="brand"><span id="nowtime"></span> </li>
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" style="font-size: 16px"><i
                            class="icon-cog"></i> Extra <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="<?php echo "http://".$nrserver; ?>">Node-red</a></li>
              <li><a href="<?php echo $phpurl; ?>">phpMyAdmin</a></li>
              <li><a href="https://github.com/msillano/tuyaDAEMON">GitHub</a></li>
            </ul>
          </li>
           </ul>
      </div>
      <!--/.nav-collapse -->
    </div>
    <!-- /container -->
  </div>
  <!-- /navbar-inner -->
</div>
<!-- /navbar -->
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
            <li  class="active">
              <a href="index.php"><i class="icon-dashboard"></i><span><?php echo $Translation['Dashboard']; ?></span></a>
            </li>
            <li>
              <a href="chart.php"><i class="icon-bar-chart"></i><span><?php echo $Translation['Charts']; ?></span></a>
			</li>
            <li>
              <a href="note.php"><i class="icon-list-alt"></i><span><?php echo $Translation['Notes'] ?></span></a>
            </li>
			<li>
              <a href="garden.php"><i class="icon-tint"></i><span><?php echo $Translation['Sprinklers']; ?></span></a>
            </li>
      </ul>
    </div>
    <!-- /container -->
  </div>
  <!-- /subnavbar-inner -->
</div>
<!-- /subnavbar -->

<div class="main">
  <div class="main-inner">
    <div class="container">
      <div class="row">
        <div class="span6">
          <div class="widget widget-nopad">
            <div class="widget-header"> <i class="icon-list-alt"></i>
              <h3> Tempo reale</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
              <div class="widget big-stats-container">
                <div class="widget-content">
                  <table class="table table-striped table-bordered action-table">
	                  <tbody>
			<?php
			// set the data area widget, defined by  $ItemsNumber, $items[]
			  for ($i= 1; $i <=  $ItemsNumber; $i++) {
                      echo '<tr><td width="40%"><h4>';
                      echo $items[$i].'  '.$units[$i];
                      echo '</h4></td><td  id="td-value'.$i.'"><h1 style="text-align: center">'."\n";
                      echo '<span class="value" id="value'.$i.'">...</span>';
                      echo '</h1></td><td  width="58px" class="td-actions">';
	                  if ($i == 3)
	                      echo '<a class="btn btn-large"  style="margin-right: 0;" onclick="toggleAction('.$i.')"><i  id="toggle'.$i.'" style="color: #7eb216"  class="icon-off icon-large"></i></a>'."\n";

	                  echo '</td><td width="58px" class="td-actions"><a class="btn btn-large" style="margin-right: 0;"  href="base-chart.php?index='.$i.'"><i class="icon-bar-chart">'.$Translation['Charts'].'</i></a></td></tr>'."\n";
					  }      ?>

                    </tbody>
                  </table>
                 </div>
                <!-- /widget-content -->

              </div>
            </div>
          </div>
          <!-- /widget -->
          <div class="widget widget-nopad">
            <div class="widget-header"> <i class="icon-pencil"></i>
              <h3> <?php echo $Translation['TODO calendar'] ?></h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
              <div id='calendar'>
              </div>
            </div>
            <!-- /widget-content -->
          </div>
               <!-- /widget -->
        </div>
        <!-- /span6 -->
        <div class="span6">

       	<div class="widget">
            <div class="widget-header"> <i class="icon-signal"></i>
              <h3> Today power</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
             <canvas id="area-chart" class="chart-holder" height="250" width="430"> </canvas>
              <!-- /area-chart -->
            </div>
            <!-- /widget-content -->
          </div>
          <div class="widget widget-nopad">
                  <div class="widget-header"><i class='icon-bolt'></i>

                       <h3>P&P energy/month</h3>

                    </div><!-- /widget-header -->
                    <div class="widget-content">
                      <table class="table table-striped">
  <thead>
    <tr>
      <th>&nbsp;</th>
      <th>Total [kWh]</th>
      <th>Grid [kWh]</th>
      <th>P&P [kWh]</th>
      <th><a>green [%]</a></th>
    </tr>
  </thead>
<?php echo $MonthBody; ?>
</table>

                    </div>
                    <!-- /widget-content -->
              </div>
              <!-- /widget -->

		  <div class="widget widget-nopad">
              <div class="widget-header"><i class='icon-pencil'></i>

                   <h3><a href="note.php"><?php echo $Translation['Notes']; ?></a></h3>

                </div><!-- /widget-header -->
                <div class="widget-content">
                  <ul class="news-items">
                     <?php echo $notes ; ?>
                  </ul>
                </div>
                <!-- /widget-content -->
          </div>
          <!-- /widget -->

          <!-- /widget -->
          <div class="widget">
          <div class="widget-header"> <i class="icon-link"></i>
              <h3><?php echo $Translation['Links']; ?></h3>
            </div>
        <div class="widget-content">
              <div class="shortcuts">
				    <a href="https://github.com/msillano/tuyaDAEMON"  target="_blank" class="shortcut"><i
				                    class="shortcut-icon icon-github-sign"></i><span
                          class="shortcut-label">infos</span> </a>
			      <a href="<?php echo 'http://'.$nrserver; ?>"  target="_blank" class="shortcut"><i
				                    class="shortcut-icon icon-sitemap"></i><span
                          class="shortcut-label">node-red</span> </a>
				    <a href="<?php echo $phpurl; ?>" target="_blank"class="shortcut" data-toggle="tooltip"
              title="usr: root, <br>pssw: root"><i
                            class="shortcut-icon  icon-cogs"></i><span
								          class="shortcut-label">myAdmin</span> </a>
			      <a href="<?php echo 'https://www.e-distribuzione.it/'; ?>"  target="_blank" class="shortcut" data-toggle="tooltip"
              title="usr: a_name,<br>pssw: a_pass" ><i
				                    class="shortcut-icon  icon-bolt"></i><span
					                class="shortcut-label">e.distribuzione</span> </a>
      		  <a href="<?php echo 'https://www.servizioelettriconazionale.it/'; ?>"  target="_blank" class="shortcut" data-toggle="tooltip"
              title="usr: a_name,<br>pssw: a_pass"><i
				                    class="shortcut-icon  icon-bolt"></i><span
					                class="shortcut-label">S. E. N.</span> </a>
            <a href="https://www.arera.it/it/dati/eep35.htm"  target="_blank" class="shortcut"><i
                            class="shortcut-icon icon-bolt"></i><span
                          class="shortcut-label">costo kWh</span> </a>
            <a href="https://re.jrc.ec.europa.eu/pvg_tools/en/"  target="_blank" class="shortcut"><i
                            class="shortcut-icon icon-picture"></i><span
                          class="shortcut-label">PVGIS</span> </a>
            <a href="https://www.sunearthtools.com/dp/tools/pos_sun.php"  target="_blank" class="shortcut"><i
                            class="shortcut-icon icon-picture"></i><span
                          class="shortcut-label">SunEarth</span> </a>
         	</div>
              <!-- /shortcuts -->
            </div>
            <!-- /widget-content -->
          </div>
          <!-- /widget -->


           </div>
        <!-- /span6 -->
      </div>
      <!-- /row -->
    </div>
    <!-- /container -->
  </div>
  <!-- /main-inner -->
</div>
<!-- /main -->
<!--
<div class="extra">
  <div class="extra-inner">
    <div class="container">
      <div class="row">
                    <div class="span3">
                   </div>
               </div>
    </div>
  </div>
  -->
</div>
<!-- /extra -->
<div class="footer">
  <div class="footer-inner">
    <div class="container">
      <div class="row">
        <div class="span12"> &copy; 2022 M.Sillano &nbsp;&nbsp; &copy; 2013 Bootstrap Responsive Admin Template. </div>
        <!-- /span12 -->
      </div>
      <!-- /row -->
    </div>
    <!-- /container -->
  </div>
  <!-- /footer-inner -->
</div>
<!-- /footer -->
<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery-1.7.2.min.js" type="text/javascript"></script>
<script src="js/excanvas.min.js"     type="text/javascript"></script>
<script src="js/chart.min.js"        type="text/javascript"></script>
<script src="js/bootstrap.js"        type="text/javascript"></script>
<script src="js/full-calendar/fullcalendar.min.js" type="text/javascript"></script>
<script src="js/base.js"             type="text/javascript"></script>

<script>
// =========== from php, java array

<?php echo $array_monthNames ?>
<?php echo $array_monthNamesShort ?>
<?php echo $array_dayNames ?>
<?php echo $array_dayNamesShort ?>


// ================================== page js functions

 <?php echo  " daemonURL= 'http://$nrserver'; \n"; ?>  // defined in 'interface.php'.
 <?php echo  " deviceAC = '$deviceAC'; \n"; ?>
 <?php echo  " devicePV = '$devicePV'; \n"; ?>
 <?php echo  " offsAC   = $offsAC; \n"; ?>
 <?php echo  " offsPV   = $offsPV; \n"; ?>
// global var data
var rtdata ;

function myentryFunction() {
// sent 2 real SCHEMA commands via _system/_ToFastCmd, to fill tuyastatus array, just in case...
 valuex = {'device': deviceAC };
 daemonREST('_system','_toFastIN', JSON.stringify(valuex) );
 valuex = {'device': devicePV };
 daemonREST('_system','_toFastIN', JSON.stringify(valuex) );

// changes some colors
$("#value2").css("color","blue") ;
$("#value3").css("color","green") ;
$("#value4").css("color","red") ;
}

function myexitFunction(){
}

// =============================   ON/OFF button:
// HTML: <a class="btn btn-large"  style="margin-right: 0;" onclick="toggleAction('.$i.')"><i  id="toggle'.$i.'" name="OFF" style="color: #7eb216"  class="icon-off icon-large"></i></a>
//  beaviohur: button change color and send command

// const TOGGLEON   =  "#db3325" ;
// const TOGGLEOFF  =  "#7eb216" ;
// const TOGGLENONE =  "#e5e5e5" ;
 const TOGGLEON   =  "#7eb216" ;
 const TOGGLEOFF  =  "#2E86C1" ;
 const TOGGLENONE =  "#e5e5e5" ;

// called as onclick(), does command (daemonREST)
function toggleAction(id){
 	 if (id == 3){
		status = toggleButton(3);
		daemonREST(devicePV, "switch",status);
	 }
}
// required by some IE
function rgb2hex(rgb) {
     if (  rgb.search("rgb") == -1 ) {
          return rgb;
     } else {
          rgb = rgb.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d+))?\)$/);
          function hex(x) {
               return ("0" + parseInt(x).toString(16)).slice(-2);
          }
          return "#" + hex(rgb[1]) + hex(rgb[2]) + hex(rgb[3]);
     }
}

function toggleButton(num, value = null){
   rgb = $("#toggle"+num).css("color");
   status = rgb2hex(rgb);
   newst = "NONE";
switch(status){
	case TOGGLEOFF:
		newst = "ON";
	break;
	case TOGGLEON:
		newst = "OFF";
	break;
   }
setButton(num, newst);
return (newst);
};

function setButton(num, value){   // value ON/OFF/NONE
   if (value == "ON"){
        $("#toggle"+num).attr("style", "color:"+TOGGLEON);
        return;
	}
  if (value == "OFF"){
        $("#toggle"+num).attr("style", "color:"+TOGGLEOFF);
        return;
	}
//  $("#toggle"+num).attr("style", "color:"+TOGGLENONE);
  $("#toggle"+num).attr("style", "color:"+TOGGLEON);
        return;
}
// ------------ end BUTTON

var auto_refresh = setInterval(readRefresh, 1137); // refresh time quantum

var roundrobin =3;
var tot = 0;

$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});

function readRefresh(){
 // round robin data refresh to keep fast the Interval handler
getLocalTimeStamp('#nowtime');
let res = 0;
let scr ="?";
roundrobin = (++roundrobin)%5;

switch (roundrobin){
	case 0:
res = JSON.parse(daemonREST(deviceAC, "_6.V"));
scr = isNaN(res.value)? res.value: Number(res.value).toFixed(1);
$("#value1").html(scr);
	      break
	case 1:
res = JSON.parse(daemonREST(deviceAC, "_6.W"));
scr = isNaN(res.value)? res.value: (res.value).toFixed(1);
$("#value4").html(scr);
tot = res.value;
	      break
	case 2:
res = JSON.parse(daemonREST(devicePV, "10"));
scr = isNaN(res.value)? res.value: Number(res.value).toFixed(1);
$("#value3").html(scr);
tot = isNaN(res.value)? tot: tot+res.value ;
	      break
	case 3:
scr = isNaN(tot)? "---": tot.toFixed(1);
$("#value2").html(scr);
// update totals
scr = (DBdata[1][8] - offsPV).toFixed(1) + " (" +offsPV+")" ;
$("#value5").html(scr);
//
scr = (DBdata[1][4] - offsAC).toFixed(1) + " (" +offsAC+")" ;
$("#value6").html(scr);
	     break
	case 4:
  res = JSON.parse(daemonREST(devicePV, "switch"));
  setButton(3, res.value );
       break
}

}

//======================================================
var	labx = new Array();
var	dinx = new Array();
var	pvx = new Array();

   var lineChartData = {
            labels: getDBdata("labels"),
            datasets: [
					{
					label: "Green",
                    borderColor: 'rgb(126,178,22 )',
                    backgroundColor: 'rgba(126,178,22, 0.3)',
					fill: true,
     cubicInterpolationMode: 'monotone',
      tension: 0.4,
				    data:  getDBdata("PV")
				},
			    {
					label: "Total",
                  borderColor: 'rgb(125, 189, 232)',
	                backgroundColor: 'rgba(125, 189, 232, 0.3)',
     cubicInterpolationMode: 'monotone',
      tension: 0.4,
				    fill: true,
				    data:  getDBdata("DIN")
				}
			]
        };

 var simpleLine ={
    type: 'line',
    data: lineChartData,
    options: {
		pointRadius: 1,
        scales: {
            x: {
   	        dispay:true,
                title: {
	                dispay:true,
     				text:"hour"
				    }
            },
           y: {
   	        dispay:true,
			stacked:true,
            title: {
	                dispay:true,
     				text:"Power [W]"
				    }
            }
        },
     plugins:{
		 tooltip:{
             callbacks: {
                    title: function(tooltipItems) {
	// 				let tit = "at "+ context[0].xLabel + ":00";
    //                return tit;
	    if(tooltipItems.length > 0) {
            const item = tooltipItems[0];
            const labels = item.chart.data.labels;
            const labelCount = labels ? labels.length : 0;
            if (labelCount > 0 && item.dataIndex < labelCount) {
                return 'at '+labels[item.dataIndex] + ':00';
                }
		}
         return '';

		    	}
		  }
	   }
      }
   }
 };


function getDBdata(what){
   if (labx.length < 1){
   DBdata.forEach(function(row) {
		       if (row[0]){
		         labx.push(row[0]);
 	           dinx.push(row[1]);
				     pvx.push(row[5]?row[5]:0);  // transforms NULL to 0
               }
			     });
	}
	if (what == 'labels') return(labx);
	if (what == 'DIN') return(dinx);
  if (what == 'PV') return(pvx);
	return(labx);
}

 var myLine = new Chart(document.getElementById("area-chart").getContext("2d"),simpleLine );
    // ====  for Calendar  runtime: ======================
firstDay = <?php echo $firstDay ?>;  // of week: from daemon-use.php
//
var l = window.location;
var base_url = l.protocol + "//" + l.host + "/";
	// uses mysql see wwwdaemon/extradata.php

function saveEvent(title, start, end, allDay ) {
 aurl = base_url+'wwwdaemon/extradata.php?addEvent=yes';
 // double encode for text, because ',' not allowed in reading (CSV)
 aurl += '&title='+encodeURIComponent(encodeURIComponent(title));
 tstart = encodeURIComponent(start.getTimeStamp());
 aurl += '&start='+tstart;
 tend = encodeURIComponent(end.getTimeStamp());
 aurl += '&end='+tend;
 if (allDay) {
      aurl += '&allDay=1';
   } else {
       aurl += '&allDay=0';
   }
 $.get( aurl , function(buffer){});
// $.get( aurl , function(buffer){alert(" Buffer "+ buffer);});
}

function requestURL(action, start, end) {
 aurl = base_url+'wwwdaemon/extradata.php?'+action+'=yes';
 aurl += '&start='+encodeURIComponent(start.getTimeStamp());
 aurl += '&end='+encodeURIComponent(end.getTimeStamp());
 aurl += '&_='+Math.round(10000*Math.random( ));
 return (aurl);
}

//=========================  callback

    $(document).ready(function() {
  //   init page data
        readRefresh();
  //  init calendar
       var calendar = $('#calendar').fullCalendar({
          header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
          },
          selectable: true,
          selectHelper: true,
          monthNames: monthNames,
          monthNamesShort: monthNamesShort,
          dayNames: dayNames,
          dayNamesShort: dayNamesShort,
          timeFormat: 'H(:mm)',
          firstDay: firstDay,
          allDayDefault: true,
// delete event
       eventClick: function(calEvent, jsEvent, view) {
         // change the border color just for fun
        $(this).css('border-color', 'red');
        var truthBeTold = window.confirm("TODO: ["+calEvent.title + "]\n\nClick OK to delete.");
        if (truthBeTold) {
             aurl = base_url+'wwwdaemon/extradata.php?killEvent=yes&rowid='+calEvent.id;

  //         $.get( aurl, function(buffer){alert(" Buffer "+ buffer);});
             $.get( aurl, function(buffer){});
             calendar.fullCalendar( 'removeEvents', calEvent.id );
             return;
             }
        $(this).css('border-color', '');
        },
// add event
        select: function(start, end, allDay) {
            var title = prompt('Event Title:');
            if (title) {
              saveEvent(title, start, end, (allDay?1:0) );
              calendar.fullCalendar('renderEvent',
                {
                  title: title,
                  start: start,
                  end: end,
                  allDay: allDay,
                 },
                true // make the event "stick"
              );
            }
            calendar.fullCalendar('unselect');
          },
// get events from DB
         events: function(start, end, callback) {
           $.get( requestURL('getEvent', start, end) , function(buffer){
//			   alert(" Buffer "+ buffer);
           lines = buffer.split('|');
           var events = new Array();
           for ( i= 0 ; i< lines.length; i++){
             riga = lines[i];
             if (riga.indexOf(',') > 0) {
                fields = riga.split(',');
                events.push({
                    id: fields[4].trim(),
                    title: decodeURIComponent(fields[3]),
                    start:  fields[0].trim(),
                    end: fields[1].trim(),
                    allDay:(fields[2].trim() != 0 )
                   });
             }
          }  // for
          if (events.length > 0){
              callback(events);
              }
            });
        }   // events
      }); // fullCalendar
    });  // ready
 // ================= general low level
function makeTimeStamp(){
 var s = this.getFullYear()+ "-";
   s += (this.getMonth() <9? "0"+ (this.getMonth() + 1):(this.getMonth() + 1)) + "-";
   s += (this.getDate() <10? "0"+ this.getDate():this.getDate()) + ' ';
   s += (this.getHours() <10? "0"+ this.getHours():this.getHours()) + ":";
   s += (this.getMinutes() <10? "0"+ this.getMinutes():this.getMinutes()) + ":";
   s += (this.getSeconds() <10? "0"+ this.getSeconds():this.getSeconds());
   return s;
   }
function makeISO8601(){
 var s = this.getFullYear()+ "-";
   s += (this.getMonth() <9? "0"+ (this.getMonth() + 1):(this.getMonth() + 1)) + "-";
   s += (this.getDate() <10? "0"+ this.getDate():this.getDate()) + 'T';
   s += (this.getHours() <10? "0"+ this.getHours():this.getHours()) + ":";
   s += (this.getMinutes() <10? "0"+ this.getMinutes():this.getMinutes()) + ":";
   s += (this.getSeconds() <10? "0"+ this.getSeconds():this.getSeconds());
   return s;
   }

Date.prototype.getTimeStamp = makeTimeStamp;
Date.prototype.getISO8601 = makeISO8601;
// ===========
function getLocalTimeStamp(where){
// use date() to get data and time from local PC,
// then format timeStamp and set #timestamp_local
 d = new Date();
 //Create Date object.
  $(where).html(d.getTimeStamp());
 }

 function httpGet(url) {
 // low level function, used by daemonREST
       let xhr = new XMLHttpRequest();
       xhr.open('GET', url, false);  // fast sycronous implementation
       try {
		xhr.send();
        if (xhr.status != 200) {
           alert(`Error ${xhr.status}: ${xhr.statusText}`);
           } else {
//	     alert('Rquest OK: ' + url);
	       return(xhr.response); }
       } catch(err) {  alert('Request failed: ' + err);}
	}

// to send GET,SET, SCHEMA request to tuyaDAEMON (locale)
// To have a fast REST:
// - GET returns last value in 'tuyastatus' (can be also 'none')
// - SET returns always 'sent'. To verify rersult you must do a GET
// - SCHEMA returns last values in 'tuyastatus'
// - to do a real SCHEMA command use SET ...
function daemonREST(device, property = null, value = null) {
 theURL = daemonURL + '/tuyaDAEMON?device=' + encodeURIComponent(device) + ((property)? (('&property=' + encodeURIComponent(property)) + ((value)? ('&value=' + encodeURIComponent(value)):'')) : '');
 return (httpGet(theURL));
 }


    </script><!-- /Calendar -->
</body>
</html>
