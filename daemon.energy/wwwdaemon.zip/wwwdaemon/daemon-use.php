<?php
// =========== Config data / read only ==========
  $ver = '1.01';                // do not change

setlocale(LC_ALL, null);   // get fronm system
$locale_info = localeconv();

// echo 'decimal_point=' . $locale_info['decimal_point'] . "<br/>\n";
// echo "<pre>".print_r($locale_info)."</pre><br>";

// ===== START  translations ===================
// for index page, RT data
 $ItemsNumber = 6;
 $items = array (              // [0]=>  widget title, required
  'tuyaDEAMON Energy',
  'Tensione',
  'Consumo',
  'plug&play',
  'Rete',
  'FV mese',
  'Rete mese'  );

	 $units = array (
  '',                         // [0] not used, requires $ItemsNumber +1 elements
  '[V]',
  '[W]',
  '[W]',
  '[W]',
  '[kWh]',
  '[kWh]');
 // ================== END page confilg
  // general use (calendar etc.) (Translation only)
   $monthNames      = Array('Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre');
   $monthNamesShort = Array ('Gen','Feb','Mar','Apr','Mag','Giu','Lug','Ago','Set','Ott','Nov','Dic');

   $dayNames      = Array ('Domenica','Luned&#x00EC;','Marted&#x00EC;','Mercoled&#x00EC;','Gioved&#x00EC;','Venerd&#x00EC;','Sabato');
   $dayNamesShort = Array ('Dom','Lun','Mar','Mer','Gio','Ven','Sab');
   $firstDay = 1;       // of week : 0: Domenica, 1: Lunedì
   //
    $chartlabel = array (
   '',
  'Watt(carico)',
  'Watt(FV)',
  'Watt(rete)',
  'Tensione'
   );
  //  the right extra menu items (Translation only)
  $setup = array (
   'Configurazione',
   'Aiuto',
   'Data Base  (per esperti)',
   'TuyaDAEMON (per esperti)'
  );
  $Translation['Arduino chart0'] = 'Arduino centralina idroponica: grafico per TIC';
  // index items:
  $Translation['Dashboard'] = 'Energia';
  $Translation['Charts'] = 'Grafici';
  $Translation['Events'] = 'Eventi';
   $Translation['Sprinklers'] = 'Irrigatori';
 // dasboard page
  $Translation['Actual reading'] = 'Valori aggiornati';
  $Translation['TODO calendar'] = 'Agenda';
  $Translation['Notes'] = 'Appunti';
  $Translation['Value']   = 'Lettura';
  $Translation['Status']  = 'Stato';
  $Translation['Links']  = 'Link utili';
  $Translation['Today power'] = 'Grafico 24 ore';
// note edit page
  $Translation['Title'] = 'Titolo';
  $Translation['Text'] = 'Testo';
  $Translation['save'] = 'salva';
  $Translation['delete'] = 'elimina';
  $Translation[''] = '';
  $Translation[''] = '';
  $Translation[''] = '';
  $Translation[''] = '';
  $Translation[''] = '';
  $Translation[''] = '';
  $Translation[''] = '';
  $Translation[''] = '';
  $Translation[''] = '';
  $Translation[''] = '';
  $Translation[''] = '';
  $Translation[''] = '';
  $Translation[''] = '';
  $Translation[''] = '';
  $Translation[''] = '';


?>
