<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>tuyaDAEMON green: notes</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/pages/dashboard.css" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
<?php
      $d=dirname(__FILE__);
      include("$d/interface.php");
      include("$d/daemon-use.php");
/*
 echo '<pre>';
 print_r($_GET);   // to see this enable alert(buffer) on caller.
 print_r($_POST);   // to see this enable alert(buffer) on caller.
 echo '</pre>';  	  
*/        
     $noteTemplate ='       
        
              <li>
                      <div class="news-item-date">
                        <span class="news-item-day"><!-- DAY --></span> <span class="news-item-month"><!-- MONTH --></span>
                      </div>
                      <div class="news-item-detail span8">
                        <p style="color: #66CC33" class="news-item-title" target="_blank"><!-- TITLE --></p>
                        <p class="news-item-preview"><!-- BODY --></p>
                      </div>
                      <div class="pull-right">
                       <a class="btn btn-small" href="<!-- URL -->"><i class="icon-trash"></i> '.$Translation['delete'].'</a>
                      <div>
                    </li>
    ';    
        
        

      //Array ( [newtitle] => titolo [newtext] => corpo [newNote] => [newtime] => 2014-08-26 19:57:58 )
  if (isset($_POST['newNote'])){
      $_GET = $_POST;
    }
    
 if (isset($_GET['newNote'])){
     if (( trim($_GET['newtitle']) != '') && ( trim($_GET['newtext']) != '')) {
        $sql =  'INSERT INTO `wwwdaemon`.`notes` VALUES (NULL,"'.$_GET['newtime'].'","'.$_GET['newtitle'].'","'.$_GET['newtext'].'")';
         // connessione php-db
 //   $db = new SQLite3('/mnt/sda1/datalogger.sqlite');	
    $db = mysqli_connect($servername, $username, $password, $appdbase);   
	if ($db===false) die('Errore in use  db.');	
        // esegue query
        $db->query($sql); 
        }    
   
    }
   
if (isset($_GET['killnew'])){
    $sql =  'DELETE FROM  `wwwdaemon`.`notes` WHERE noteid ='.$_GET['id'];
     // connessione php-db
 //   $db = new SQLite3('/mnt/sda1/datalogger.sqlite');	
    $db = mysqli_connect($servername, $username, $password, $appdbase);
    if ($db===false) die('Errore in use  db.');	
    // esegue query
    $db->query($sql);  
    }
   
   
   
    $notes = '';
    $query  = "SELECT * FROM  `wwwdaemon`.`notes` ORDER BY ndate DESC";
     // connessione php-db
     //   $db = new SQLite3('/mnt/sda1/datalogger.sqlite');	
    $db = mysqli_connect($servername, $username, $password, $appdbase);
   
   if ($db===false) die('Errore in use  db.');	
    // esegue query
   $result = $db->query($query);  
   if ($result===false) die('Errore in query.' );	

   // ===  CREA  $note 
   // righe 
    $colonne =  $result->field_count;
    while($row = $result->fetch_array()) {
      $ndata = $noteTemplate; 
      $day = "";
        // 2014-08-12 09:00:00
        // 01234567890
     if (substr( $row[1],8,1) == "0"){
          $day = substr( $row[1],9,1);
        } else {
          $day = substr( $row[1],8,2);
        }
		$ndata = str_replace("<!-- DAY -->",$day,$ndata);
    $nm = substr( $row[1],5,2);
	   if (strlen($nm) >1)
         $month = $monthNamesShort[(int)$nm - 1];
	    else $month = "???";
		$ndata = str_replace("<!-- MONTH -->",$month,$ndata);
		$ndata = str_replace("<!-- TITLE -->",urldecode($row[2]),$ndata);
		$ndata = str_replace("<!-- BODY -->",urldecode($row[3]),$ndata);
    $url ='note.php?killnew=yes&id='.$row[0];
    $ndata = str_replace("<!-- URL -->",$url,$ndata);
    $notes .= $ndata;
    } // while
   ?>
 </head>
<body >
<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"><span
                    class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span> </a><a class="brand" href="index.html">TuyaDaemon <?php echo $Translation['Events']; ?>  </a>
      <div class="nav-collapse">
        <ul class="nav pull-right">
		
		 <li class="brand"><span id="nowtime"></span> </li>
         <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                            class="icon-cog"></i> Extra <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="<?php echo "http://".$nrserver; ?>">Node-red</a></li>
              <li><a href="<?php echo $phpurl; ?>">phpMyAdmin</a></li>
              <li><a href="https://github.com/msillano/tuyaDAEMON">GitHub</a></li>
            </ul>
          </li>
           </ul>
      </div>
      <!--/.nav-collapse --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /navbar-inner --> 
</div>
<!-- /navbar -->
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
            <li  >
              <a href="index.php"><i class="icon-dashboard"></i><span><?php echo $Translation['Dashboard']; ?></span></a>
            </li>
            <li>
              <a href="chart.php"><i class="icon-bar-chart"></i><span><?php echo $Translation['Charts']; ?></span></a>
			</li>
            <li class="active">
              <a href="note.php"><i class="icon-list-alt"></i><span><?php echo $Translation['Notes'] ?></span></a>
            </li>
			<li>
              <a href="garden.php"><i class="icon-tint"></i><span><?php echo $Translation['Sprinklers']; ?></span></a>
            </li>
      </ul>
    </div>
    <!-- /container --> 
  </div>
  <!-- /subnavbar-inner --> 
</div>
<!-- /subnavbar -->  <div class="main">
      <div class="main-inner">
        <div class="container">
          <div class="row">
            <!-- row -->
             <div class="span11">
              <div class="widget widget-nopad">
                <div class="widget-header">
                  <h3>
                   <?php echo $Translation['Notes'] ?>
                  </h3>
                </div><!-- /widget-header -->
                <div class="widget-content">
                    <ul class="news-items">
                    <li>
                 <form action="note.php" method="post" >
                       <div class="news-item-detail span9"><?php echo $Translation['Title'] ?><br>
                        <input id="newtitle" name="newtitle" style="color: #66CC33" class="news-item-title span8" type="text"><br>
                        <?php echo $Translation['Text'] ?><br>
                          <textarea id="newtext" name="newtext" class="span8"  rows="7" cols="100" ></textarea>
                      </div>
                                       <input type="hidden" name="newtime" id="newtime"> 
									   <div class="pull-right">
                       <h4> Nuovo</h4><br>
                       </div>
           		    <div ><center>
						<button class="btn btn-invert" type="submit" name="newNote" >
                      <i class="icon-save"></i> <?php echo $Translation['save'] ?>
                    </button></center>
					</div>
                  

                      </form>
                    </li>
                    <!-- here the notes list -->
                     <?php echo $notes ; ?>
                  </ul>
                </div><!-- /widget-content -->
              </div><!-- /widget -->
            </div><!-- /span4 -->
          </div><!-- /row -->
        </div><!-- /container -->
      </div><!-- /main-inner -->
    </div><!-- /main -->
    <!-- Le javascript
================================================== --><!-- Placed at the end of the document so the pages load faster -->

<script language="javascript" type="text/javascript" src="js/jquery-1.7.2.min.js">
</script><script language="javascript" type="text/javascript" src="js/bootstrap.js">
</script><!-- arduino -->
<script type="text/javascript">
 // ================= general low level

function makeTimeStamp(){
 var s = this.getFullYear()+ "-";   
   s += (this.getMonth() <9? "0"+ (this.getMonth() + 1):(this.getMonth() + 1)) + "-";   
   s += (this.getDate() <10? "0"+ this.getDate():this.getDate()) + ' ';                      
   s += (this.getHours() <10? "0"+ this.getHours():this.getHours()) + ":";
   s += (this.getMinutes() <10? "0"+ this.getMinutes():this.getMinutes()) + ":"; 
   s += (this.getSeconds() <10? "0"+ this.getSeconds():this.getSeconds());
   return s;
   }
Date.prototype.getTimeStamp = makeTimeStamp;

// set desktop and idden field
function updateTime(){
 $('#nowtime').text(new Date().getTimeStamp());
 $('#newtime').val(new Date().getTimeStamp());
 }
// ===========
   
$(document).ready(function() {
     var auto_refresh = setInterval(updateTime, 2421); // refresh time quantum
 });


    </script>
  </body>
</html>
