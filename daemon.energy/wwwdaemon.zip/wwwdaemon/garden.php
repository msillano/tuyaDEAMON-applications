<!DOCTYPE html>
<html lang="it">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta charset="utf-8">
       <title>tuyaDAEMON home</title>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, maximum-scale=2.0, user-scalable=yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
 <!--  <link href="css/fonts-googleapis-com.css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet" type="text/css"> -->
    <link href="css/font-awesome.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/pages/dashboard.css" rel="stylesheet" type="text/css">
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements, remote: http://html5shim.googlecode.com/svn/trunk/html5.js -->
    <!--[if lt IE 9]>
      <script src="js/html5.js"></script>
    <![endif]-->
 <?php
 	  //
      $d=dirname(__FILE__);
      include("$d/daemon-use.php");      //  the langage file
      include("$d/interface.php");       //  php stuff

// 8 irrigation points definitions
  $pointdata = array (
//                 x,    y,  L/m,  sup, time
  "A1" => array( 1370,  380,  8,    40,  35),
  "A2" => array( 1300,  500,  7.8,  20,  18),
  "A3" => array( 1240,   80,  7.2,  21,  20),
  "B1" => array( 1020,   80,  7.1,  15,  15),
  "B2" => array(  770,  240,  0.4,   4,  70),
  "B3" => array(  440,   80,  4,    15,  30),
  "B4" => array(  860,   80,  5.3,  19,  25));

  $offICO = "img/pointOFF.png";
  $onICO  = "img/pointON.png";      // ico name MUST contain 'ON': used as check
?>

<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/base.js"></script>

<script type = "text/javascript">
// ================= general low level
function makeTimeStamp(){
var s = this.getFullYear()+ "-";
  s += (this.getMonth() <9? "0"+ (this.getMonth() + 1):(this.getMonth() + 1)) + "-";
  s += (this.getDate() <10? "0"+ this.getDate():this.getDate()) + ' ';
  s += (this.getHours() <10? "0"+ this.getHours():this.getHours()) + ":";
  s += (this.getMinutes() <10? "0"+ this.getMinutes():this.getMinutes()) + ":";
  s += (this.getSeconds() <10? "0"+ this.getSeconds():this.getSeconds());
  return s;
  }
function makeISO8601(){
var s = this.getFullYear()+ "-";
  s += (this.getMonth() <9? "0"+ (this.getMonth() + 1):(this.getMonth() + 1)) + "-";
  s += (this.getDate() <10? "0"+ this.getDate():this.getDate()) + 'T';
  s += (this.getHours() <10? "0"+ this.getHours():this.getHours()) + ":";
  s += (this.getMinutes() <10? "0"+ this.getMinutes():this.getMinutes()) + ":";
  s += (this.getSeconds() <10? "0"+ this.getSeconds():this.getSeconds());
  return s;
  }

Date.prototype.getTimeStamp = makeTimeStamp;
Date.prototype.getISO8601 = makeISO8601;
// ===========
function getLocalTimeStamp(where){
// use date() to get data and time from local PC,
// then format timeStamp and set #timestamp_local
d = new Date();
//Create Date object.
 $(where).html(d.getTimeStamp());
}

// ****************************** general tuyaDAEMO comminications
  <?php echo  " daemonURL= 'http://$nrserver'; \n"; ?>  // defined in 'interface.php'.

 function httpGet(url) {
 // low level function, used by daemonREST
      let xhr = new XMLHttpRequest();
       xhr.open('GET', url, false);  // fast sycronous implementation
       try {
		xhr.send();
        if (xhr.status != 200) {
           alert(`Error ${xhr.status}: ${xhr.statusText}`);
           } else {
//	     alert('Rquest OK: ' + url);
	       return(xhr.response); }
       } catch(err) {  alert('Request failed: ' + err);}
	}

// to send GET,SET, SCHEMA request to tuyaDAEMON (locale, remote)
// To have a fast REST:
// - GET returns last value in 'tuyastatus' (can be also 'none';
// - SET returns always 'sent'. To verify rersult you must do a GET
// - SCHEMA returns last values in 'tuyastatus'
function daemonREST(device, property = null, value = null) {
 theURL = daemonURL + '/tuyaDAEMON?device=' + encodeURIComponent(device) + ((property)? (('&property=' + encodeURIComponent(property)) + ((value)? ('&value=' + encodeURIComponent(value)):'')) : '');
 return (httpGet(theURL));
 }

// ==============================================  HTML user interation
// ======  imgbutton wudget
// the HTML: <img src="img/pointOFF.png" alt="A2" name="A2" id="A2" onclick="togglePoint('A2');" style="cursor: pointer; position: absolute; top: 100px; left:200px;">
function set_imgbutton(id, value, on_ico, off_ico){
  var ipoint = document.getElementById(id);
  if (value){
 	 ipoint.src = on_ico;
	 return(true);
 }
   else {
     ipoint.src = off_ico;
	 return(false);
    }
}

function toggle_imgbutton(id, on_ico, off_ico){
  var ipoint = document.getElementById(id);
  nextvalue = !ipoint.src.includes("ON");
  set_imgbutton(id, nextvalue, on_ico, off_ico);
  return(nextvalue);
}

// ================  This is APPLICATION-PAGE specific

// irrigation Points on garden (imgbotton)
//   show irrigation status
//   onclick: toggles status.
// ptid: see php pointdata table = A1.. B4
// used button images files (see also in php):

 offICO = "img/pointOFF.png";
 onICO  = "img/pointON.png";      // ico name MUST contain 'ON': used as check
//
function setPoint(ptid, value){
	set_imgbutton(ptid, value, onICO, offICO);
}
//
// ================================= PUBLIC HTML FUNCTIONS
function togglePoint(ptid){
// ON/OFF watering (used in php as onclick function)
switch (ptid) {
  case "A1":
     if (toggle_imgbutton(ptid, onICO, offICO)){
         	daemonREST("irrigazione anteriore","relay4", "ON");
          daemonREST("irrigazione laterale","switch all", "OFF");
        }
     else
        	daemonREST("irrigazione anteriore","relay4", "OFF");
    break;
    case "A2":
      if (toggle_imgbutton(ptid, onICO, offICO)){
      	daemonREST("irrigazione anteriore","relay2", "ON");
        daemonREST("irrigazione laterale","switch all", "OFF");
      }
         else
      	daemonREST("irrigazione anteriore","relay2", "OFF");
        break;
    case "A3":
      if (toggle_imgbutton(ptid, onICO, offICO)){
      	daemonREST("irrigazione anteriore","relay3", "ON");
        daemonREST("irrigazione laterale","switch all", "OFF");
      }
         else
      	daemonREST("irrigazione anteriore","relay3", "OFF");
        break;
    case "B1":
      if (toggle_imgbutton(ptid, onICO, offICO)){
      	daemonREST("irrigazione laterale","relay2", "ON");
        daemonREST("irrigazione anteriore","switch all", "OFF");
      }
         else
      	daemonREST("irrigazione laterale","relay2", "OFF");
        break;
    case "B2":
      if (toggle_imgbutton(ptid, onICO, offICO)){
      	daemonREST("irrigazione laterale","relay1", "ON");
        daemonREST("irrigazione anteriore","switch all", "OFF");
      }
       else
      	daemonREST("irrigazione laterale","relay1", "OFF");
        break;
    case "B3":
      if (toggle_imgbutton(ptid, onICO, offICO)){
      	daemonREST("irrigazione laterale","relay4", "ON");
        daemonREST("irrigazione anteriore","switch all", "OFF");
      }
         else
      	daemonREST("irrigazione laterale","relay4", "OFF");
        break;
    case "B4":
          if (toggle_imgbutton(ptid, onICO, offICO)){
          	daemonREST("irrigazione laterale","relay3", true);
            daemonREST("irrigazione anteriore","switch all", "OFF");
          }
           else
          	daemonREST("irrigazione laterale","relay3", "OFF");
            break;
    default:

   }
}
// ======================== refresh

var auto_refresh = setInterval(readRefresh, 1021); // refresh time quantum

var roundrobin =3;
var tot = 0;

$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});

function readRefresh(){
 // round robin data refresh to keep fast the Interval handler
getLocalTimeStamp('#nowtime');
let res = 0;
let scr ="?";
roundrobin = (++roundrobin)%5;
switch (roundrobin){
	case 0:
  src = daemonREST("irrigazione anteriore","relay4");
  res = JSON.parse(src);
  if ( res.value)
  setPoint("A1", res.value === "ON");
  src = daemonREST("irrigazione anteriore","relay2");
  res = JSON.parse(src);
  if ( res.value)
  setPoint("A2", res.value === "ON");
  break;

  case 1:
  src = daemonREST("irrigazione anteriore","relay3");
  res = JSON.parse(src);
  if ( res.value)
  setPoint("A3", res.value === "ON");
  src = daemonREST("irrigazione laterale","relay2");
  res = JSON.parse(src);
    if ( res.value)
  setPoint("B1", res.value === "ON");
  break;

  case 2:
  src = daemonREST("irrigazione laterale","relay1");
  res = JSON.parse(src);
  if ( res.value)
  setPoint("B2", res.value === "ON");
  src = daemonREST("irrigazione laterale","relay4");
  res = JSON.parse(src);
  if ( res.value)
  setPoint("B3", res.value === "ON");
  break;

  case 3:
  src = daemonREST("irrigazione laterale","relay3");
  res = JSON.parse(src);
  if ( res.value)
    setPoint("B4", res.value === "ON");
  break;

  default:
    }
}
</script>


</head>
<body style="font-family: sans-serif" width="1783" >
<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"><span
                    class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span> </a><a class="brand"
                    href="index.html">TuyaDaemon <?php echo $Translation['Sprinklers']; ?>  </a>
      <div class="nav-collapse">
        <ul class="nav pull-right">

		      <li class="brand"><span id="nowtime"></span> </li>
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" style="font-size: 16px"><i
                            class="icon-cog"></i> Extra <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="<?php echo "http://".$nrserver; ?>">Node-red</a></li>
              <li><a href="<?php echo $phpurl; ?>">phpMyAdmin</a></li>
              <li><a href="https://github.com/msillano/tuyaDAEMON">GitHub</a></li>
              <li><a href="https://github.com/msillano/tuyaDEAMON-applications">apps</a></li>
            </ul>
          </li>
           </ul>
      </div>
      <!--/.nav-collapse -->
    </div>
    <!-- /container -->
  </div>
  <!-- /navbar-inner -->
</div>
<!-- /navbar -->
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
            <li >
              <a href="index.php"><i class="icon-dashboard"></i><span><?php echo $Translation['Dashboard']; ?></span></a>
            </li>
            <li>
              <a href="chart.php"><i class="icon-bar-chart"></i><span><?php echo $Translation['Charts']; ?></span></a>
			</li>
            <li>
              <a href="note.php"><i class="icon-list-alt"></i><span><?php echo $Translation['Notes'] ?></span></a>
            </li>
			<li   class="active">
              <a href="garden.php"><i class="icon-tint"></i><span><?php echo $Translation['Sprinklers']; ?></span></a>
            </li>
      </ul>
    </div>
    <!-- /container -->
  </div>
  <!-- /subnavbar-inner -->
</div>
<!-- /subnavbar -->

	 <div class="main" width="1783" height="679" style="position:relative;">
   <!-- the main image	 -->
       <img src="img/garden02.png"  width="1783" height="679" alt="home" border="0">
            <!-- builds 8 img buttons on top -->
<?php
// adds irrigation points to HTML, based on pointdata table:
    foreach($pointdata as $id => $data){
     echo '<img src="img/pointOFF.png" ';
     echo "alt='$id' name='$id' id='$id' onclick='togglePoint(\"$id\");' style='cursor: pointer;
       position: absolute; top: ".$data[1]."px; left:".$data[0]."px;' data-toggle='tooltip'
              title='T: ".$data[4]." min' />\n";
     }
?>


<! ---- meteo widget standard -->
   <table width="330" style="position: absolute; top:370px; left:420px;"><tr><td>
        <a class="weatherwidget-io" href="https://forecast7.com/it/41d2313d09/san-felice-circeo/" data-icons="Climacons" data-days="3" data-theme="original" data-basecolor="rgba(255, 255, 255, 0)" data-textcolor="#f9f9f9" data-lowcolor="#b4d2fe" >San Felice Circeo, Province of Latina, Italy</a>
         <script>
         !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='https://weatherwidget.io/js/widget.min.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','weatherwidget-io-js');
         </script>
  	 </td>
	 </tr>
   </table>
 </div>
   </body>
</html>
