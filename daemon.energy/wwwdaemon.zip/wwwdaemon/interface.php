<?php
// constants - options
 $titlefile ="/interval.txt";

//  ===================  local/remote servers
// note: use absolute urls

 $phpurl   = "http://192.168.100.100:8080/phpmyadmin/";
// $phpurl   = "http://192.168.1.3/phpmyadmin/";
// $phpurl   = "http://192.168.100.100:10000/";
// $phputl   = "http://192.168.1.23:10000/";

// same as in tuyaDAEMON.global.REMOTEMAP, default 'localhost:1880' (WEB server in same computer as node-red).
// $nrserver = "localhost:1880";
// $nrserver   = "192.168.1.3:1984";
// $nrserver = "192.168.100.119:2022";
 $nrserver   = "192.168.100.100:2022";

// $servername = "localhost";
// $servername = "192.168.1.3";
 $servername = "192.168.100.100";

// =====  MySQL database definitions
 $username   = "root";
 $password   = "root";

$database    = "tuyathome";
$datastorage = "storico";
$appdbase    = "wwwdaemon";

// Devices:
// note: used 'dps' are defined in index.php page (from global.alldevices)
$deviceAC = "mainAC";
$devicePV = "inverter_p&p";


function round4($num){
    return (intval($num*10000)/10000);
}
// ============================== idro
// magic value -10000 <=> none
// from Coeff to user value
  function makeNone($value, $mx, $qx) {
     if (($value == 'none') || ($value == -10000)){
       return "none";
     }
  return (sprintf("%.4f",($value * ($mx)) + ($qx))) ;
  }

// from user value to Coeff value
  function makeValue($str,$mx,$qx) {
     if ((trim($str) == 'none') || ($str == -10000)){
       return -10000;
     }
  return  intval(( Number($str) - $qx)/$mx);
  }

// =================================================== low level utility

 // utility func for  saveCoeff() and  makeJavaArray())
  function  quote($v){
      if (is_numeric($v))  return $v;
      return "'$v'";
  }

// to transfer simple arrays from php to Jscript
// php array $array == (eg) $monthNames
// jscript array name == (eg) monthNames
// php use:  "$array_xxx =  makeJavaArray('monthNames', $monthNames);"
// jscript placeholder:  '< ? php echo $array_xxx; ? >'
 function makeJavaArray($name, $array) {
      $template = " var $name = new Array(";
      for ($i = 0; $i < count($array); $i++ ) {
           $template .= ($i>0)?",\n":'';
           $template .=  quote($array[$i]);
      }
      $template .= " );\n\n";
      return $template;
  }


  // saves an array of arrays/values as file  "include" php
 // no recursive, only 2 levels
  function saveCoeff($xarray, $file) {
    $d=dirname(__FILE__);
    if(!$fp=@fopen("$d/$file", "w")){
			exit;
		}else{
            fwrite($fp, "<?php\n");
            fwrite($fp, '$coeff = Array ('."\n");
            foreach ($xarray as $v => $arr) {
                if ($v != 'end') {
                    if (is_array($arr)){
                      fwrite($fp, '    '.quote($v)." => Array (\n");
                      reset($arr);
                      list($chiave, $valore) = each($arr);
                      fwrite($fp, '          '.quote($chiave).' => '.quote($valore));
                      while (list($chiave, $valore) = each($arr)) {
                          fwrite($fp, ",\n");
                          fwrite($fp, '          '.quote($chiave).' => '.quote($valore));
                      }
                      fwrite($fp, "),\n");
                    } else {
                      fwrite($fp, '  '.quote($v).' => '.quote($arr).",\n");
                    }
                }
            }
	        fwrite($fp, "  'end' => 0");
          fwrite($fp, ")\n");
	        fwrite($fp, "?>\n");
		      fclose($fp);
        }
    }

?>
