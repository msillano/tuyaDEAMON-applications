    var nodesVis,  edgesVis,  network;
	var coId = 0;
    var cId = 2;
      // create an array with nodes
	const nodes =[];
     // create an array with edges
	const edges =[];
    //  
	var deviceList = {};   //  format as reponse form REST
    const dIndex = [];  //  [deviceList.list position] => Vis-idx
	//
	if ( collect == "live")
	   deviceList = JSON.parse(daemonREST(null));
 	else
	   deviceList = getAllDevices();

// ============ local functions	(CUSTOMIZATION optional)
	
function getIcon(dev, connected = false){
	 var   theIcon = {  // default
                    code: "\uf1b2",  // fa-cube
                    color: "DarkGray", // unconnected color
                    };
     if (modules.includes(dev)) {
		      theIcon = { // module default
                    code: "\uf1d2",  // fa-git-square
                    color: "OliveDrab"
                    };
// special CORE icons
          if (modules.indexOf(dev) == 0) { // core
              theIcon = {
                    code: "\uf174",
                    color: "OrangeRed"
			        };
		  };
          if (modules.indexOf(dev) == 1) { // tuya_bridge as device
                // adds extra device
                  theIcon = {
                    code: "\uf074",
                    color: "HotPink"
                    };
  	     };
       return (theIcon);			 
	   }  // modules ends
// ==== TODO CUSTOMIZATION icon for special user devices	   
        if (dev.startsWith("Temp")) {
                theIcon['code'] = "\uf2c8";
            } else
                if (dev.startsWith("Termo")) {
                    theIcon['code'] = "\uf045";
                } else
                    if (dev.includes("Gateway")) {
                        theIcon['code'] = "\uf1eb";
                    }
// ===== TODO ENDS					
	if (connected) 	theIcon['color'] =	"HotPink";
    return (theIcon);
}

function filterDP(device, devData = {_connected: "none"}){
	 if (device == 'CORE_devices' ) {     // extra node not in TuyaDAEMON
		 return {mode : collect +" devices", count: deviceList.list.length };
	     }
	 if (device == 'core_TRIGGER' ) {     // extra node not in TuyaDAEMON
		 return {_connected : true };
	     }
	
// TODO ======= Customize for tooltip optimization.		 
	 if (device.startsWith("Termo")) {
//		 console.log("input ",devData);
		 // too many data: only a subset. 'none' default value for missed
		 newData ={};
	     newData['Device']             = (devData['Device'])?devData['Device']:'none';
		 newData['Temperature']        = (devData['Temperature'])?devData['Temperature']:'none';
		 newData['Target T']           = (devData['Target T'])?devData['Target T']:'none';
	     newData['Actual T offset']    = (devData['Actual T offset'])?devData['Actual T offset']:'none';
	 	 newData['Hist. day real T']   = (devData['Hist. day real T'])?devData['Hist. day real T']:'none';
		 newData['Hist. day target T'] = (devData['Hist. day target T'])?devData['Hist. day target T']:'none';
		 newData['Hist. day power']    = (devData['Hist. day power'])?devData['Hist. day power']:'none';
//		 console.log("output ",newData);
	     return newData;
	 } 
// ..... here more ....	 
	 
	 return devData;    // default: nothing to do
 }
// ============ CUSTOMIZATION ENDS
// =========================== local functions
function addExtraDevice(device){
	          // defaults
            nx = {
				label: device,
                icon: getIcon(device),
                title: "_connected: none",
                }; 
            deviceList.list.push(device);
            idx = deviceList.list.indexOf(device);			
            // ------------ 
            nx['id'] = cId;
  			dIndex[idx] = cId;
            nodesVis.add(nx);

            nx = {};
            nx['from'] = coId;
            nx['to'] = cId++;
            edgesVis.add(nx);
}
	
function addNewDevices(){
	alld = JSON.parse(daemonREST("_system", "_doUPDATE")).value.all_devices;
	alld.forEach((line, idx) => {
          device = line.split(";")[0].trim();
		  if (!live_devices.list.includes(device)){
			 addExtraDevice(device);
		  }
	});
}	
	
 function getAllDevices(){
	 live_devices = JSON.parse(daemonREST(null));
 if (live_devices.list.includes(modules[4])){
	  daemonREST("_system", "_doUPDATE", "all");
	  setTimeout(addNewDevices, 8000);
	  console.log("core_SYSTEM exists ... doing all devices");
	  return (live_devices);
 } else {
	  console.log("core_SYSTEM don't exist ... doing live devices");
	  collect = "live";
	  console.log(live_devices);
	  return (live_devices);
     }
 }	 
 
function deviceData(device){
	// reads SCHEMA data, returns it usr-filtered and strigfied
	   var devData = {} ;
	   if (deviceList.list.includes(device)){
          devData = daemonREST(device);
          devData = JSON.parse(devData).schema;
	   }
	   devData = filterDP(device, devData);	  
      const datastr = "" + JSON.stringify(devData, null, '\t');
	  // string cosmetics:
	  return (datastr.slice(2).slice(0,-2).split('"').join(''));  
      }	

function nodeTooltip(node){  	// updates node by new tooltip
        node['title'] = deviceData(node.label);
      }

// main function, creates network		  
function drawFontAwesome4() {
	// defoult options
    const options = {
        locale: 'it',
// CUSTOMIZATION ============== comment / uncomment next line		
  //         interaction:{navigationButtons :true },  // add NAVIGATION BUTTONS
// customization ends
        nodes: {
            icon: {
                face: 'FontAwesome',
                size: 50,
            }, // prepara per usare icone FontAwesome
            shape: "icon",
        },
    };
// ============== node 1) THE server
    server = deviceList.remote_from;
    server = server.split(".")[1] + " CORE";
    nodes.push({
        id: 1,
        label: server,
// HOME special ICON: // not in devicelist		
        icon: {
            code: "\uf233",
            color: "DarkSlateGray"  // like black
          // color: "SlateGray"
        },
    });

 // ============= processing modules/devices (live)
    var nx = {};
    deviceList.list.forEach((device, idx) => {
        // ----------- First pass: only modules
        if (modules.includes(device)) {
            // ---- as module
            nx = {};
            nx['id'] = cId;
            nx['label'] = device;
			nx['icon'] = getIcon(device, true)
			// builds dIndex: array position => node id
			dIndex[idx] = cId;
            // --------- special cases
            if (modules.indexOf(device) == 0) { // core
                coId = cId;
                nx['label'] = 'CORE_devices';
            } // core ends
            if (modules.indexOf(device) == 1) { // tuya_bridge as module (only one time)
				nx['icon'] = {
                    code: "\uf1d2",  // fa-git-square
                    color: "OliveDrab"
                    };
                nx['label'] = 'core_TRIGGER';
                } 
				nodeTooltip(nx);
	        
			nodes.push(nx);
            //
            nx = {
                from: 1
            };
            nx['to'] = cId++;
            nx["value"] = 1;
            edges.push(nx);

            if (modules.indexOf(device) == 1) { // tuya_bridge
                // adds extra device
                nx = {id: cId};
                nx['label'] = device;
                nx['icon'] = {
// special ICON for tuya_bridge	as bridge				
                    code: "\uf074",
                    color: "Purple"
                };
				nx['title'] = "countdown:0";	
                nodes.push(nx);
				
                nx = {};
                nx['from'] = cId - 1;  // the core_TRIGGER  node
				dIndex[idx] = cId;  // adjust index
                nx['to'] = cId++;
                edges.push(nx);
            } // tuya_bridge ends
        }
    });

    deviceList.list.forEach((device, idx) => {
        // ----------- now processing  all devices:
        if ((!modules.includes(device)) || (modules.indexOf(device) == 1)) {
            // defaults
            nx = {label: device}; 
            nx['id'] = cId;
    		dIndex[idx] = cId;
            nodeTooltip(nx);
		    isOK = !(nx['title'].includes('_connected: false') || nx['title'].includes('_connected: none'));
          	nx['icon'] = getIcon(device, isOK);
            nodes.push(nx);

            nx = {};
            nx['from'] = coId;
            nx['to'] = cId++;
            edges.push(nx);

        };

    });

 // =============================================================
 // prepares the arguments
   const container = document.getElementById("mynetwork");
   nodesVis = new vis.DataSet(nodes);
   edgesVis = new vis.DataSet(edges);
   var data = {
           nodes: nodesVis,
           edges: edgesVis,
      };
// grants font preload
   if (document.fonts) {
        // Decent browsers: Make sure the fonts are loaded.
        document.fonts
        .load('normal normal 400 24px/1 "FontAwesome"')
        .catch(console.error.bind(console, "Failed to load Font Awesome 4."))
        .then(function () {
            // create a network
            const network = new vis.Network(container, data, options);
        })
        .catch(
            console.error.bind(
                console,
                "Failed to render the network with Font Awesome 4."));
    } else {
        // IE: Let's just hope the fonts are loaded (they're probably not,
        // hence the timeout).
        window.addEventListener("load", function () {
            setTimeout(function () {
                // create a network
               network = new vis.Network(container, data, options);
            }, 500);
        });
    };
}
// ======================== refresh
var roundrobin =-1;
var auto_refresh = setInterval(readRefresh, refreshTime); // refresh time quantum

function readRefresh(){
  roundrobin = ++roundrobin % deviceList.list.length;
  adev = deviceList.list[roundrobin];
  console.log("NOW."+roundrobin+" "+adev);
  const txt = deviceData(adev);
//  console.log("GET."+roundrobin+" >> "+txt);
  // Exception: core
  if (modules.indexOf(adev) == 0) { // core
     nodesVis.update([{ id: 1, title: txt}]);
     const txt2 = deviceData('CORE_devices');
     nodesVis.update([{ id: coId, title: txt2}]);
     }
  else {
	 isConn = !(txt.includes('_connected: false') || txt.includes('_connected: none'));
     nodesVis.update([{ id: dIndex[roundrobin], icon: getIcon(adev, isConn)}]);
     nodesVis.update([{ id: dIndex[roundrobin], title: txt}]);
     }
   }

 