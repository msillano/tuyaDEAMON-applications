// to send GET,SET, SCHEMA request to tuyaDAEMON (locale, remote)
// To have a fast REST:
// - GET returns last value in 'tuyastatus' (can be also 'none';
// - SET returns always 'sent'. To verify rersult you must do a GET
// - SCHEMA returns last values in 'tuyastatus'

// daemonURL  MUST be defined
// sycronous implementation, for fast local networks
// Copyright  2024  marco.sillano@gmail.com
function daemonREST(device, property = null, value = null) {

   function httpGet(url) {
 // low level function, used by daemonREST
      let xhr = new XMLHttpRequest();
       xhr.open('GET', url, false);  // fast sycronous implementation
       try {
		xhr.send();
        if (xhr.status != 200) {
           alert(`Error ${xhr.status}: ${xhr.statusText}`);
           } else {
//	     alert('Rquest OK: ' + url);
	       return(xhr.response); }
       } catch(err) {  alert('Request failed: ' + err);}
	};
	
 theURL = daemonURL + ((device)? ('?device=' + encodeURIComponent(device)):'') + ((property)? (('&property=' + encodeURIComponent(property)) + ((value)? ('&value=' + encodeURIComponent(value)):'')) : '');
 return (httpGet(theURL));
 }
