<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Dashboard - Bootstrap Admin Template</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/pages/dashboard.css" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
	    <?php
	  // this setup the notes widget... 
      $d=dirname(__FILE__);
      include("$d/daemon-use.php");      //  the langage file
      include("$d/interface.php");       //  php stuff
 
 // also for jscript
      $array_monthNames = makeJavaArray( 'monthNames', $monthNames);
      $array_monthNamesShort = makeJavaArray( 'monthNamesShort', $monthNamesShort);
      $array_dayNames = makeJavaArray( 'dayNames', $dayNames);
      $array_dayNamesShort = makeJavaArray( 'dayNamesShort', $dayNamesShort);
     
?>	

</head>
<body>
<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"><span
                    class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span> </a><a class="brand" href="index.html">TuyaDaemon <?php echo $Translation['Charts']; ?>  </a>
      <div class="nav-collapse">
        <ul class="nav pull-right">
		
		  <li class="brand"><span id="nowtime"></span> </li>
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                            class="icon-cog"></i> Extra <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="<?php echo "http://".$nrserver; ?>">Node-red</a></li>
              <li><a href="<?php echo $phpurl; ?>">phpMyAdmin</a></li>
              <li><a href="https://github.com/msillano/tuyaDAEMON">GitHub</a></li>
            </ul>
          </li>
           </ul>
      </div>
      <!--/.nav-collapse --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /navbar-inner --> 
</div>
<!-- /navbar -->
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
            <li >
              <a href="index.php"><i class="icon-dashboard"></i><span><?php echo $Translation['Dashboard']; ?></span></a>
            </li>
            <li class="active">
              <a href="chart.php"><i class="icon-bar-chart"></i><span><?php echo $Translation['Charts']; ?></span></a>
			</li>
            <li>
              <a href="note.php"><i class="icon-list-alt"></i><span><?php echo $Translation['Notes'] ?></span></a>
            </li>
			<li>
              <a href="garden.php"><i class="icon-tint"></i><span><?php echo $Translation['Sprinklers']; ?></span></a>
            </li>
      </ul>
    </div>
    <!-- /container --> 
  </div>
  <!-- /subnavbar-inner --> 
</div>
<!-- /subnavbar -->
<div class="main">
  <div class="main-inner">
    <div class="container">
      <div class="row">
        <div class="span12">
            </div>
        <!-- /span12 --> 
      </div>
      <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /main-inner --> 
</div>
<!-- /main -->

<div class="footer">
  <div class="footer-inner">
    <div class="container">
      <div class="row">
          <div class="span12"> &copy; 2022 M.Sillano &nbsp;&nbsp; &copy; 2013 Bootstrap Responsive Admin Template. </div>
        <!-- /span12 --> 
      </div>
      <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /footer-inner --> 
</div>
<!-- /footer --> 
<!-- Le javascript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="js/jquery-1.7.2.min.js"></script> 
<script src="js/excanvas.min.js"></script> 
<script src="js/chart.min.js" type="text/javascript"></script> 
<script src="js/bootstrap.js"></script>
<script language="javascript" type="text/javascript" src="js/full-calendar/fullcalendar.min.js"></script>
<script src="js/base.js"></script> 
<script>     
// refresh time (& data)
var auto_refresh = setInterval(readRefresh, 998); // refresh time quantum

function readRefresh(){
 // round robin data refresh to keep fast the Interval handler
getLocalTimeStamp('#nowtime');
}
// ------------------  low level by refresh
function getLocalTimeStamp(where){    
// use date() to get data and time from local PC,
// then format timeStamp and set #timestamp_local
 d = new Date();           
 $(where).html(d.getTimeStamp());
 }      

function makeTimeStamp(){
 var s = this.getFullYear()+ "-";   
   s += (this.getMonth() <9? "0"+ (this.getMonth() + 1):(this.getMonth() + 1)) + "-";   
   s += (this.getDate() <10? "0"+ this.getDate():this.getDate()) + ' ';                      
   s += (this.getHours() <10? "0"+ this.getHours():this.getHours()) + ":";
   s += (this.getMinutes() <10? "0"+ this.getMinutes():this.getMinutes()) + ":"; 
   s += (this.getSeconds() <10? "0"+ this.getSeconds():this.getSeconds());
   return s;
   }
Date.prototype.getTimeStamp = makeTimeStamp;

</script><!-- /refresh -->
</body>
</html>
