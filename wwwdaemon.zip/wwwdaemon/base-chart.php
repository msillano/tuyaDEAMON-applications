<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>daemon energy charts</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/pages/dashboard.css" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
	    <?php
// generic
      $d=dirname(__FILE__);
      include("$d/daemon-use.php");      //  the langage file
      include("$d/interface.php");       //  php stuff

 // also for jscript
 /*
      $array_monthNames = makeJavaArray( 'monthNames', $monthNames);
      $array_monthNamesShort = makeJavaArray( 'monthNamesShort', $monthNamesShort);
      $array_dayNames = makeJavaArray( 'dayNames', $dayNames);
      $array_dayNamesShort = makeJavaArray( 'dayNamesShort', $dayNamesShort);
*/
      ?>
<?php
// processing offset (if any)
 if (isset($_POST['offMain'])) $_GET = $_POST;  // POST or GET
 $offMain = (isset($_GET['offMain']))? $_GET['offMain'] : 0;
 $offRef = (isset($_GET['offRef']))? $_GET['offRef'] : 0;

//  here chart differences:
 $chartID = (isset($_GET['index']))? $_GET['index'] : 1;
 switch ($chartID) {
     case 1:
     case 2:
         $query2  = "SELECT * FROM (SELECT `timestamp`, `GRID_V`, `GRID_W` + `PV_ACW` from `storico`.`power5m` ORDER BY `timestamp` DESC LIMIT 2017) AS tmp ORDER BY `timestamp` asc ;";
         $chartName ="Week tension[V] & power[W] total";
         break;
     case 3:
     case 4:
         $query2  = "SELECT * FROM (SELECT `timestamp`, `PV_ACW`, `GRID_W` from `storico`.`power5m` ORDER BY `timestamp` DESC LIMIT 2017) AS tmp ORDER BY `timestamp` asc ;";
         $chartName ="Week green[W] & grid[W] power";
         break;
     case 5:
     case 6:
         $query2  = "SELECT * FROM (SELECT `timestamp`, `PV_KWH`, `GRID_KWH` from `storico`.`power5m` ORDER BY `timestamp` DESC LIMIT 2017) AS tmp ORDER BY `timestamp` asc ;";
         $chartName ="Week green[kWh] & grid[kWh] energy";
       break;
 }

 // ------------ data for grafh 2017
     $db = new mysqli($servername, $username, $password, "storico");
     if ($db->connect_errno) {
         die('Errore nella connessione al database.'. $db->connect_error);
         }
     $result = $db->query($query2);
 // ===  transforms DATA to a js array of arrays (DBdata).
    $data = '' ;
    $colonne =  $db->field_count;
    echo "<script> \n var DBdata =[ \n";

     while($row = $result->fetch_array()) {
 		         echo '[ ';
  		      	 for($c = 0; $c < $colonne; $c++) {
                     if ($c == 0){
          // format timestamp
 						$h = substr($row[0],11,2);
 						if (substr( $h, 0, 1 ) === "0")
 						   	$h = substr($h,1);
            $m = substr($row[0],13,3);
            if ($h == 0) {
              echo  '"'. substr($row[0],5,5).'"';
            } else
 					    echo  '"'.$h.$m.'"';
 					} else  {
//            echo ','.($row[$c]?$row[$c]:0);  // to replace NULL with 0
            echo ','.$row[$c];  // to replace NULL with 0
                     }
 				 }
   		         echo " ], \n ";
 	             }

                  echo " []]; </script>";
   //   $db->free_result($result);
   while($db->next_result()){
      if($l_result = $db->store_result()){
              $l_result->free();
      }
    }

   $db->close();
 // -----
?>
<script>
// =========== from php, java array
/*
<?php echo $array_monthNames ?>
<?php echo $array_monthNamesShort ?>
<?php echo $array_dayNames ?>
<?php echo $array_dayNamesShort ?>
*/
// some stuff here
var myLine  = null;
  //myLine.resetZoom();
</script>
</head>
<body>
<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"><span
                    class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span> </a><a class="brand" href="index.html">TuyaDaemon <?php echo $Translation['Charts']; ?>  </a>
      <div class="nav-collapse">
        <ul class="nav pull-right">

		  <li class="brand"><span id="nowtime">...</span> </li>
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"  style="font-size: 16px"><i
                            class="icon-cog"></i> Extra <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="<?php echo "http://".$nrserver; ?>">Node-red</a></li>
              <li><a href="<?php echo $phpurl; ?>">phpMyAdmin</a></li>
              <li><a href="https://github.com/msillano/tuyaDAEMON">GitHub</a></li>
            </ul>
          </li>
           </ul>
      </div>
      <!--/.nav-collapse -->
    </div>
    <!-- /container -->
  </div>
  <!-- /navbar-inner -->
</div>
<!-- /navbar -->
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
            <li >
              <a href="index.php"><i class="icon-dashboard"></i><span><?php echo $Translation['Dashboard']; ?></span></a>
            </li>
            <li class="active">
              <a href="chart.php"><i class="icon-bar-chart"></i><span><?php echo $Translation['Charts']; ?></span></a>
			</li>
            <li>
              <a href="note.php"><i class="icon-list-alt"></i><span><?php echo $Translation['Notes'] ?></span></a>
            </li>
			<li>
              <a href="garden.php"><i class="icon-tint"></i><span><?php echo $Translation['Sprinklers']; ?></span></a>
            </li>
      </ul>
    </div>
    <!-- /container -->
  </div>
  <!-- /subnavbar-inner -->
</div>
<!-- /subnavbar -->
<div class="main">
  <div class="main-inner">
    <div class="container">
      <div class="row">
        <div class="span12">
            </div>
		 	<div class="widget">
            <div class="widget-header"> <i class="icon-signal"></i>
            <?php echo "<h3>$chartName</h3>"; ?>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
             <canvas id="area-chart" class="chart-holder" height="900" width="1783"> </canvas>
              <!-- /area-chart -->
            </div>
			<div class="widget-footer">
          <form action='base-chart.php'>
	<!--		<button onclick="myLine.resetZoom();">RESET ZOON</button>  -->
           <input type="hidden"  id="index" name="index" value = <?php echo $chartID; ?> />
           <a class="btn btn-large"  onclick="myLine.zoom(1.2);" style="color: #333333"  >zoomIN</a>	 &nbsp;&nbsp;
	         <a class="btn btn-large"  onclick="myLine.zoom(0.8);" style="color: #333333"  >zoomOUT</a> &nbsp;&nbsp;
	         <a class="btn btn-large"  onclick="myLine.resetZoom();" style="color: #333333"  >RESET ZOOM</a>	 &nbsp;&nbsp;
		     	<button class="btn btn-large"  type="submit">REFRESH</button> &nbsp;&nbsp;
        	<input type="text"  id="offMain" style="width: 50px;"  value = <?php echo $offMain; ?> name="offMain" >OffsetMain</input>&nbsp; &nbsp;&nbsp;
		    	<input type="text"  id="offRef"  style="width: 50px;"  value = <?php echo $offRef; ?>  name="offRef" >OffsetRef</input>
			</form>
	            </div>

            <!-- /widget-content -->
          </div>
          <!-- /widget -->
     <!-- /span12 -->
      </div>
      <!-- /row -->
    </div>
    <!-- /container -->
  </div>
  <!-- /main-inner -->
</div>
<!-- /main -->

<div class="footer">
  <div class="footer-inner">
    <div class="container">
      <div class="row">
          <div class="span12"> &copy; 2022 M.Sillano &nbsp;&nbsp; &copy; 2013 Bootstrap Responsive Admin Template. </div>
        <!-- /span12 -->
      </div>
      <!-- /row -->
    </div>
    <!-- /container -->
  </div>
  <!-- /footer-inner -->
</div>
<!-- /footer -->
<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/excanvas.min.js"></script>
<script src="js/chart.min.js" type="text/javascript"></script>
<script src="js/hammer-min.2.0.8.js" type="text/javascript"></script>
<script src="js/chartjs-plugin-zoom.min.js" type="text/javascript"></script>
<script src="js/bootstrap.js"></script>
<script language="javascript" type="text/javascript" src="js/full-calendar/fullcalendar.min.js"></script>

<script>
// ============ refresh time (& data)
var auto_refresh = setInterval(readRefresh, 998); // refresh time quantum

function readRefresh(){
// round robin data refresh to keep fast the Interval handler
getLocalTimeStamp("#nowtime");
}
// ------------------  low level by refresh
function getLocalTimeStamp(where){
// use date() to get data and time from local PC,
// then format timeStamp and set #timestamp_local
 d = new Date();
 $(where).html(d.getTimeStamp());
 }

function makeTimeStamp(){
 var s = this.getFullYear()+ "-";
   s += (this.getMonth() <9? "0"+ (this.getMonth() + 1):(this.getMonth() + 1)) + "-";
   s += (this.getDate() <10? "0"+ this.getDate():this.getDate()) + ' ';
   s += (this.getHours() <10? "0"+ this.getHours():this.getHours()) + ":";
   s += (this.getMinutes() <10? "0"+ this.getMinutes():this.getMinutes()) + ":";
   s += (this.getSeconds() <10? "0"+ this.getSeconds():this.getSeconds());
   return s;
   }
Date.prototype.getTimeStamp = makeTimeStamp;
</script><!-- /refresh -->

<script>
//======================================================
var labx = [];
var mainx = [];
var refx = [];

var lineChartData = {
    labels: getDBdata("labels"),
    datasets: [{
            label: "Main",
            borderColor: 'rgb(126,178,22 )',
            backgroundColor: 'rgba(126,178,22, 0.4)',
            fill: true,
            cubicInterpolationMode: 'monotone',
            tension: 0.4,
            data: getDBdata("main"),
            yAxisID: 'y'
        }, {
            label: "Ref.",
            borderColor: 'rgb(105,105,105)',
            backgroundColor: 'rgba(192, 192, 192, 0.4)',
            data: getDBdata("ref"),
            yAxisID: 'y1'
        }
    ]
};

const scales = {
    x: {
        position: 'bottom',
    },
    y: {
        position: 'left',
        title: {
            display: true,
            text: 'Main data',
        }
    },
    y1: {
        position: 'right',
        title: {
            display: true,
            text: 'Reference',
        }
    }
};

var simpleLine = {
    type: 'line',
    data: lineChartData,
    options: {
        pointRadius: 1,
        borderWidth: 1,
        scales: scales,
        plugins: {
            tooltip: {
                callbacks: {
                    title: function (tooltipItems) {
                        if (tooltipItems.length > 0) {
                            const item = tooltipItems[0];
                            const labels = item.chart.data.labels;
                            const labelCount = labels ? labels.length : 0;
                            if (labelCount > 0 && item.dataIndex < labelCount) {
                                return 'at ' + labels[item.dataIndex] + ':00';
                            }
                        }
                        return '';
                    }
                }
            },
            zoom: {
                //limits: {
                //  x: {min: -200, max: 200, minRange: 50},
                // },
                pan: {
                    enabled: true,
                    mode: 'xy',
                    modifierKey: 'alt'
                },
			    pinch: {
                    enabled: true
                },
                zoom: {
                    mode: 'xy',
                    drag: {
                        enabled: true,
                        borderColor: 'rgb(54, 162, 235)',
                        borderWidth: 1,
                        backgroundColor: 'rgba(54, 162, 235, 0.3)'
                    },

                    wheel: {
                        enabled: true,
                    }
                }
            }
        }
    }
};

function getDBdata(what) {
    offMain =  $("#offMain").val();
    offRef =  $("#offRef").val();
    if (labx.length < 1) {
        DBdata.forEach(function (row) {
            if (row[0]) {
                labx.push(row[0]);
                mainx.push(row[1]   - offMain);
                refx.push(row[2] - offRef)
          }
        });
    }
    if (what == 'labels')
        return (labx);
    if (what == 'main')
        return (mainx);
    if (what == 'ref')
        return (refx);
    return (labx);
}

var myLine = new Chart(document.getElementById("area-chart").getContext("2d"), simpleLine);
 myLine.ZoomIn = function () {
                         zoom(myLine,1.1);
                    };


 myLine.ZoomOut = function () {
	                    var rect = document.getElementById(myLine.canvas.id).getBoundingClientRect();

                        var center = {
                            x: rect.width / 2,
                            y: rect.height / 2
                        };

                        doZoom(myLine,0.909,center);
                    };

</script> <!-- /grafh -->
</body>
</html>
