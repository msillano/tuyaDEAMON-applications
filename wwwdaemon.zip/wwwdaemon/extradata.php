<?php
header("Cache-Control: no-cache, must-revalidate"); 
header('Access-Control-Allow-Origin: *');
// DB acces for Calendar, Notes widget    
      $d=dirname(__FILE__);
      include("$d/interface.php");       //  php stuff
   
 print_r($_GET);   // to see this enable alert(buffer) on caller.
      
  // killEvent, for calendar
  if (isset($_GET['killEvent'])){
    $sql =  'DELETE FROM calendar WHERE rowid ='.$_GET['rowid'];
    $db = mysqli_connect($servername, $username, $password, "wwwdaemon");
    if ($db->connect_error)  die('Errore in use  db.');	
    $db->query($sql);  
 } // if killEvent 
  
  
 // addEvent, for calendar
  if (isset($_GET['addEvent'])){
    $sql =  'INSERT INTO calendar VALUES ("'.$_GET['start'].'","'.$_GET['end'].'","';
    $sql .= $_GET['allDay'].'","'.$_GET['title'].'", NULL )';
    $db = mysqli_connect($servername, $username, $password, "wwwdaemon");
    if ($db->connect_error)  die('Errore in use  db.');	
     $db->query($sql);  
 } // if addEvent 
     
// getEvent, for calendar
  if (isset($_GET['getEvent'])){
   $query  = "SELECT start, end, fullday, title, rowid FROM calendar ";
   $query .= 'WHERE (start >= "'.$_GET['start'].'") AND (start <= "'.$_GET['end'].'");';
   $db = mysqli_connect($servername, $username, $password, "wwwdaemon");
   if ($db->connect_error)  die('Errore in use  db.');	
   $result = $db->query($query);  
   if ($result===false) die('Errore in query.' );	
// ===  transforms DATA to CSV ascii in $data   
   $data = '' ;
   $colonne =  $db->field_count;
   while($row = $result->fetch_array()) {
 		    	for($c = 0; $c < $colonne; $c++) {   
                    if ($c > 0)  {$data .= ', ';};
                    $data .= $row[$c];  
                }  
           $data .= "|";
           }
   ob_clean();
   print($data);        
   } // if getEvent 
 
 // ===================  notes data DB
       
  // killNote, for notes
  if (isset($_GET['killNote'])){
    $sql =  'DELETE FROM notes WHERE id ='.$_GET['id'];
     // connessione php-db
   $db = mysqli_connect($servername, $username, $password, "wwwdaemon");
   if ($db->connect_error)  die('Errore in use  db.');	
    // esegue query
    $db->query($sql);  
 } // if killNote 
  
 // addNote, for notes
  if (isset($_POST['addNote'])) $_GET = $_POST;  // POST or GET
  if (isset($_GET['addNote'])){
   $sql =  'INSERT INTO notes VALUES (NULL,"'.$_GET['date'].'","'.$_GET['title'].'","'.$_GET['body'].'")';
   $db = mysqli_connect($servername, $username, $password, "wwwdaemon");
   if ($db->connect_error)  die('Errore in use  db.');	
    // esegue query
    $db->query($sql);  
 } // if addNote 
 ?>
